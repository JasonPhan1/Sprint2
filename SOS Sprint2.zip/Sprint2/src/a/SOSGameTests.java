package a;

import org.junit.jupiter.api.Assertions; // Change from org.junit.Assert
import org.junit.jupiter.api.BeforeEach; // Change from @Before
import org.junit.jupiter.api.Test; // Change from @Test

public class SOSGameTests {
    private Board board;
    private SOSGUI gui;

    @BeforeEach // Change from @Before
    public void setUp() {
        // Choosing board size
        board = new Board(3); 
    }

    // Making sure board size initialized is correct
    @Test
    public void testBoardSize() {
        Assertions.assertEquals(3, board.getBoardSize());
    }

    // Testing new board size
    @Test
    public void testNewBoardSize() {
        for (int i = 0; i < board.getBoardSize(); i++) {
            for (int j = 0; j < board.getBoardSize(); j++) {
                Assertions.assertEquals(Board.Cell.EMPTY, board.getCell(i, j));
            }
        }
    }

    // Testing to make sure Red can make a valid S or O move
    @Test
    public void testRedMove() {
        // Blue's move
        board.makeMove(0, 0);
        // Assert Blue made the move (grid[0][0] is now Blue)
        Assertions.assertEquals(Board.Cell.B, board.getCell(0, 0));
        // After Blue's move, the turn should switch to Red
        Assertions.assertEquals('R', board.getTurn());
    }
    
    // Testing to make sure Blue can make a valid S or O move
    @Test
    public void testBlueMove() {
        board.makeMove(0, 0);
        board.makeMove(0, 1);
        Assertions.assertEquals(Board.Cell.R, board.getCell(0, 1));
        Assertions.assertEquals('B', board.getTurn());
    }

    // Testing potential invalid moves
    @Test
    public void testInvalidMove() {
        board.makeMove(3, 3);
        Assertions.assertNull(board.getCell(3, 3));

        board.makeMove(0, 0);
        board.makeMove(0, 0);
        Assertions.assertEquals('R', board.getTurn());
        Assertions.assertEquals(Board.Cell.B, board.getCell(0, 0));
    }
}